from distutils.core import setup
setup(name='hello_example',
        version='1.0',
        description='a example',
        author='azhe',
        py_modules=['hello'])
